import React from 'react';

const Home = ()=>  {
  return (
    <div>
   Voici la page Home
    </div>
  );
};

export default Home;