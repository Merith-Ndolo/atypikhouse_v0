import React from 'react';

const Trending = ()=>  {
  return (
    <div>
   Voici le Trending aaahh
    </div>
  );
};

export default Trending;