import React from 'react';
import Routes from "./components/Routes";
import '../node_modules/bootstrap/dist/css/bootstrap.min.css';

const App = () => {
  return (
    <div>
      <Routes />    
    </div>
    
    
  );
};

export default App;
